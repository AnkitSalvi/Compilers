
class switch1 {
    public static void main(String args[]){
         
       int wflg=0;
       int tflg=0;
       int dflg=0;
       char c='a';    e

     switch(c)
    {
        case 'w':
        case 'W':
            wflg = 1;
            break;
        case 't':
        case 'T':
            tflg = 1;
            break;
        case 'd':
            dflg = 1;
            break;
    }
    
    }
}
